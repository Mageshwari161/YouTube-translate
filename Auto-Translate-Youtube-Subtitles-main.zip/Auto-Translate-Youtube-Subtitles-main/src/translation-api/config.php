<?php

define('CONNECTTIMEOUT', 10);
define('TIMEOUT', 11);
